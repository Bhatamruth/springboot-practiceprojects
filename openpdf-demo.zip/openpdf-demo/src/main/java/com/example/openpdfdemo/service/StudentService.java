package com.example.openpdfdemo.service;

import java.util.List;

import com.example.openpdfdemo.models.Student;


public interface StudentService {
void addStudent(Student student);
List<Student> getStudentList();
}