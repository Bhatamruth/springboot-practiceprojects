package com.example.openpdfdemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.openpdfdemo.models.Student;
public interface StudentRepoPDF extends JpaRepository<Student, Long> {}