package com.example.SchedulingTasksdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedulingTasksDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
