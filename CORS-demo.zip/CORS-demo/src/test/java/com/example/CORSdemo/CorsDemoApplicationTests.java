package com.example.CORSdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorsDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
